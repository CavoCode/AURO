// generated from rosidl_generator_c/resource/idl.h.em
// with input from solution_interfaces:msg/Example.idl
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__MSG__EXAMPLE_H_
#define SOLUTION_INTERFACES__MSG__EXAMPLE_H_

#include "solution_interfaces/msg/detail/example__struct.h"
#include "solution_interfaces/msg/detail/example__functions.h"
#include "solution_interfaces/msg/detail/example__type_support.h"

#endif  // SOLUTION_INTERFACES__MSG__EXAMPLE_H_
