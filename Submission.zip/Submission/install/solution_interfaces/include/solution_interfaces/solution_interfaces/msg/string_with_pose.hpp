// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__MSG__STRING_WITH_POSE_HPP_
#define SOLUTION_INTERFACES__MSG__STRING_WITH_POSE_HPP_

#include "solution_interfaces/msg/detail/string_with_pose__struct.hpp"
#include "solution_interfaces/msg/detail/string_with_pose__builder.hpp"
#include "solution_interfaces/msg/detail/string_with_pose__traits.hpp"

#endif  // SOLUTION_INTERFACES__MSG__STRING_WITH_POSE_HPP_
