// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__MSG__ROBOT_PUB_POSITION_HPP_
#define SOLUTION_INTERFACES__MSG__ROBOT_PUB_POSITION_HPP_

#include "solution_interfaces/msg/detail/robot_pub_position__struct.hpp"
#include "solution_interfaces/msg/detail/robot_pub_position__builder.hpp"
#include "solution_interfaces/msg/detail/robot_pub_position__traits.hpp"

#endif  // SOLUTION_INTERFACES__MSG__ROBOT_PUB_POSITION_HPP_
