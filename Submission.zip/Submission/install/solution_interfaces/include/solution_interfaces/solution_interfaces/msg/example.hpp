// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__MSG__EXAMPLE_HPP_
#define SOLUTION_INTERFACES__MSG__EXAMPLE_HPP_

#include "solution_interfaces/msg/detail/example__struct.hpp"
#include "solution_interfaces/msg/detail/example__builder.hpp"
#include "solution_interfaces/msg/detail/example__traits.hpp"

#endif  // SOLUTION_INTERFACES__MSG__EXAMPLE_HPP_
