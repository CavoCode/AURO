// generated from rosidl_generator_c/resource/idl.h.em
// with input from solution_interfaces:msg/StringWithPose.idl
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__MSG__STRING_WITH_POSE_H_
#define SOLUTION_INTERFACES__MSG__STRING_WITH_POSE_H_

#include "solution_interfaces/msg/detail/string_with_pose__struct.h"
#include "solution_interfaces/msg/detail/string_with_pose__functions.h"
#include "solution_interfaces/msg/detail/string_with_pose__type_support.h"

#endif  // SOLUTION_INTERFACES__MSG__STRING_WITH_POSE_H_
