// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__SRV__RANDOM_GOAL_HPP_
#define SOLUTION_INTERFACES__SRV__RANDOM_GOAL_HPP_

#include "solution_interfaces/srv/detail/random_goal__struct.hpp"
#include "solution_interfaces/srv/detail/random_goal__builder.hpp"
#include "solution_interfaces/srv/detail/random_goal__traits.hpp"

#endif  // SOLUTION_INTERFACES__SRV__RANDOM_GOAL_HPP_
