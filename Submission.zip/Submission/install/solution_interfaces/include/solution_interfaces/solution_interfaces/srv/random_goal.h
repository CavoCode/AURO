// generated from rosidl_generator_c/resource/idl.h.em
// with input from solution_interfaces:srv/RandomGoal.idl
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__SRV__RANDOM_GOAL_H_
#define SOLUTION_INTERFACES__SRV__RANDOM_GOAL_H_

#include "solution_interfaces/srv/detail/random_goal__struct.h"
#include "solution_interfaces/srv/detail/random_goal__functions.h"
#include "solution_interfaces/srv/detail/random_goal__type_support.h"

#endif  // SOLUTION_INTERFACES__SRV__RANDOM_GOAL_H_
