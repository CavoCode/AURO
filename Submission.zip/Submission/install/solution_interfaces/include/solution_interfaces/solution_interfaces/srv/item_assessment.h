// generated from rosidl_generator_c/resource/idl.h.em
// with input from solution_interfaces:srv/ItemAssessment.idl
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__SRV__ITEM_ASSESSMENT_H_
#define SOLUTION_INTERFACES__SRV__ITEM_ASSESSMENT_H_

#include "solution_interfaces/srv/detail/item_assessment__struct.h"
#include "solution_interfaces/srv/detail/item_assessment__functions.h"
#include "solution_interfaces/srv/detail/item_assessment__type_support.h"

#endif  // SOLUTION_INTERFACES__SRV__ITEM_ASSESSMENT_H_
