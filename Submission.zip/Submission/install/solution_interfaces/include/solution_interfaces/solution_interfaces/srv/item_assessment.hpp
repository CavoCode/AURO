// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SOLUTION_INTERFACES__SRV__ITEM_ASSESSMENT_HPP_
#define SOLUTION_INTERFACES__SRV__ITEM_ASSESSMENT_HPP_

#include "solution_interfaces/srv/detail/item_assessment__struct.hpp"
#include "solution_interfaces/srv/detail/item_assessment__builder.hpp"
#include "solution_interfaces/srv/detail/item_assessment__traits.hpp"

#endif  // SOLUTION_INTERFACES__SRV__ITEM_ASSESSMENT_HPP_
